import React from "react";
import { NavLink, Outlet } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

export default function MemberLayout() {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold">Khu vực Hội viên</h1>
          <div className="flex items-center gap-3">
            <div className="text-sm">
              <div className="font-semibold">{user?.name}</div>
              <div className="text-gray-500">{user?.email}</div>
            </div>
            <button
              onClick={logout}
              className="px-3 py-1.5 rounded-md border hover:bg-gray-100 text-sm"
            >
              Đăng xuất
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 grid grid-cols-1 md:grid-cols-[220px_1fr] gap-6">
        {/* Sidebar */}
        <aside className="bg-white rounded-xl border p-3">
          <nav className="flex md:flex-col gap-2">
            <Item to="/member">Tổng quan</Item>
            <Item to="/member/profile">Hồ sơ</Item>
            <Item to="/member/orders">Đơn hàng</Item>
            <Item to="/member/points">Điểm thưởng</Item>
          </nav>
        </aside>

        {/* Nội dung */}
        <section className="bg-white rounded-xl border p-4">
          <Outlet />
        </section>
      </main>
    </div>
  );
}

function Item({ to, children }: React.PropsWithChildren<{ to: string }>) {
  return (
    <NavLink
      to={to}
      end
      className={({ isActive }) =>
        `px-3 py-2 rounded-md text-sm ${isActive ? "bg-gray-900 text-white" : "hover:bg-gray-100"}`
      }
    >
      {children}
    </NavLink>
  );
}
