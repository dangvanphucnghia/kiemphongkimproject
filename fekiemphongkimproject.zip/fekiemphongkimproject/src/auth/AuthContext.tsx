import React, { createContext, useContext, useEffect, useMemo, useState } from "react";

type User = {
  id: string;
  name: string;
  email: string;
  tier: "Silver" | "Gold" | "Platinum";
  points: number;
} | null;

type AuthContextType = {
  user: User;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<React.PropsWithChildren> = ({ children }) => {
  const [user, setUser] = useState<User>(null);

  // Khôi phục từ localStorage
  useEffect(() => {
    const raw = localStorage.getItem("kp_user");
    if (raw) setUser(JSON.parse(raw));
  }, []);

  const login = async (email: string, _password: string) => {
    // Demo: nhận bất kỳ email/password -> tạo user giả
    const fakeUser = {
      id: "u_001",
      name: email.split("@")[0] || "Hội viên",
      email,
      tier: "Gold" as const,
      points: 1234,
    };
    setUser(fakeUser);
    localStorage.setItem("kp_user", JSON.stringify(fakeUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("kp_user");
  };

  const value = useMemo(() => ({ user, login, logout }), [user]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};
