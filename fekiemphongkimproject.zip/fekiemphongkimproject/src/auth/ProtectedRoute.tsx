import React from "react";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "./AuthContext";

export default function ProtectedRoute() {
  const { user } = useAuth();
  const loc = useLocation();
  if (!user) {
    // Chuyển về /auth và giữ ý định ban đầu
    return <Navigate to="/auth" replace state={{ from: loc }} />;
  }
  return <Outlet />;
}
