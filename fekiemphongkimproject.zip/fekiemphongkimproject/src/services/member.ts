export async function fetchOrders() {
  // demo: giả lập API call
  await delay(300);
  return [
    { id: "o1", code: "KP-2025001", date: "2025-10-21", status: "Đang giao", total: 259000 },
    { id: "o2", code: "KP-2025002", date: "2025-09-30", status: "Hoàn tất", total: 129000 },
  ];
}

export async function fetchPointsHistory() {
  await delay(200);
  return [
    { id: "p1", title: "Mua hàng", date: "2025-10-21", delta: +259 },
    { id: "p2", title: "Sử dụng voucher", date: "2025-09-30", delta: -100 },
    { id: "p3", title: "Tặng điểm sinh nhật", date: "2025-09-01", delta: +300 },
  ];
}

function delay(ms: number) {
  return new Promise(res => setTimeout(res, ms));
}
