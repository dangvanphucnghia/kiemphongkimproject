import { Routes, Route, Navigate } from "react-router-dom";
import Home from "./pages/Home";
import Auth from "./pages/Auth";

import ProtectedRoute from "./auth/ProtectedRoute";
import MemberLayout from "./layouts/MemberLayout";
import Dashboard from "./pages/member/Dashboard";
import Profile from "./pages/member/Profile";
import Orders from "./pages/member/Orders";
import Points from "./pages/member/Points";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/auth" element={<Auth />} />

      {/* Khu vực hội viên: cần đăng nhập */}
      <Route element={<ProtectedRoute />}>
        <Route path="/member" element={<MemberLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="profile" element={<Profile />} />
          <Route path="orders" element={<Orders />} />
          <Route path="points" element={<Points />} />
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
