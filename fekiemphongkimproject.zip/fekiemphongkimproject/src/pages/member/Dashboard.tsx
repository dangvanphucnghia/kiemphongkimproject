import React from "react";
import { useAuth } from "../../auth/AuthContext";

export default function Dashboard() {
  const { user } = useAuth();
  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Xin chào, {user?.name}</h2>
      <div className="grid md:grid-cols-3 gap-4">
        <Card title="Hạng hội viên" value={user?.tier || "-"} />
        <Card title="Điểm hiện tại" value={user?.points ?? 0} />
        <Card title="Ưu đãi dành cho bạn" value="Voucher -10k, freeship..." />
      </div>
    </div>
  );
}

function Card({ title, value }: { title: string; value: React.ReactNode }) {
  return (
    <div className="p-4 border rounded-lg">
      <div className="text-gray-500 text-sm">{title}</div>
      <div className="text-2xl font-bold mt-1">{value}</div>
    </div>
  );
}
