import React, { useEffect, useState } from "react";
import { fetchOrders } from "../../services/member";

type Order = Awaited<ReturnType<typeof fetchOrders>>[number];

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  useEffect(() => { fetchOrders().then(setOrders); }, []);

  return (
    <div>
      <h2 className="text-lg font-semibold mb-3">Đơn hàng của bạn</h2>
      <div className="overflow-x-auto">
        <table className="min-w-[640px] w-full text-sm">
          <thead>
            <tr className="text-left border-b">
              <th className="py-2">Mã đơn</th>
              <th>Ngày</th>
              <th>Trạng thái</th>
              <th>Tổng tiền</th>
            </tr>
          </thead>
          <tbody>
            {orders.map(o => (
              <tr key={o.id} className="border-b">
                <td className="py-2 font-medium">{o.code}</td>
                <td>{o.date}</td>
                <td>{o.status}</td>
                <td>{o.total.toLocaleString()}đ</td>
              </tr>
            ))}
            {orders.length === 0 && (
              <tr><td colSpan={4} className="py-6 text-center text-gray-500">Chưa có đơn hàng</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
