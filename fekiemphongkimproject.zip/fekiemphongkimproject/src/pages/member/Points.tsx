import React, { useEffect, useState } from "react";
import { fetchPointsHistory } from "../../services/member";

type Item = Awaited<ReturnType<typeof fetchPointsHistory>>[number];

export default function Points() {
  const [list, setList] = useState<Item[]>([]);
  useEffect(() => { fetchPointsHistory().then(setList); }, []);

  return (
    <div>
      <h2 className="text-lg font-semibold mb-3">Lịch sử điểm thưởng</h2>
      <ul className="divide-y">
        {list.map(i => (
          <li key={i.id} className="py-3 flex items-center justify-between">
            <div>
              <div className="font-medium">{i.title}</div>
              <div className="text-gray-500 text-sm">{i.date}</div>
            </div>
            <div className={`text-sm font-semibold ${i.delta >= 0 ? "text-green-600" : "text-red-600"}`}>
              {i.delta >= 0 ? `+${i.delta}` : i.delta}
            </div>
          </li>
        ))}
        {list.length === 0 && <li className="py-6 text-center text-gray-500">Chưa có lịch sử điểm</li>}
      </ul>
    </div>
  );
}
