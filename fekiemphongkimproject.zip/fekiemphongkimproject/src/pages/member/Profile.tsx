import React, { useState } from "react";
import { useAuth } from "../../auth/AuthContext";

export default function Profile() {
  const { user } = useAuth();
  const [name, setName] = useState(user?.name || "");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Demo: lưu tạm localStorage (riêng profile)
    const profile = { name, phone, address, email: user?.email };
    localStorage.setItem("kp_profile", JSON.stringify(profile));
    alert("Đã cập nhật hồ sơ (demo).");
  };

  return (
    <form onSubmit={onSubmit} className="max-w-xl space-y-4">
      <h2 className="text-lg font-semibold">Hồ sơ cá nhân</h2>
      <div>
        <label className="block text-sm text-gray-600 mb-1">Họ tên</label>
        <input className="w-full border rounded-md px-3 py-2" value={name} onChange={e=>setName(e.target.value)} />
      </div>
      <div>
        <label className="block text-sm text-gray-600 mb-1">Số điện thoại</label>
        <input className="w-full border rounded-md px-3 py-2" value={phone} onChange={e=>setPhone(e.target.value)} />
      </div>
      <div>
        <label className="block text-sm text-gray-600 mb-1">Địa chỉ</label>
        <textarea className="w-full border rounded-md px-3 py-2" value={address} onChange={e=>setAddress(e.target.value)} />
      </div>
      <button className="px-4 py-2 rounded-md bg-gray-900 text-white">Lưu thay đổi</button>
    </form>
  );
}
