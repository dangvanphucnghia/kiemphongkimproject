// postcss.config.js  (ESM)
import tailwind from '@tailwindcss/postcss'

export default {
  plugins: [tailwind],
}
